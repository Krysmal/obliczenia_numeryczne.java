package edu.lab13;

public class Main {
    public static void main(String[] args) {
        new CMainForm("Obliczanie numeryczne").setVisible(true);
    }
}